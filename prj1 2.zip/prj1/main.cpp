#include <iostream>  // std::cin, std::cout
#include <fstream>   // std::ifstream
#include <string>    // std::string
#include <vector>    // std::vector
#include <chrono>    // for calculating the elapsed time
#include "sort.h"    // importing sort functions declarations here, so compiler knows about these function.

/*
*  Compiler doesn't need to know about definition of the function
*  Linker links function calls to their definitions later 
*/


void parse(std::string& str) {
    for (int i = str.size()-1; i >= 0; --i) {
        if (!std::isalpha(str[i])) {
            str.erase(str.begin() + i);
        }
        str[i] = std::tolower(str[i]);
    }
}
 
int read(std::fstream& file, std::vector<std::string>& words) {
    int counter {};
    while (file) {
        std::string str;
        file >> str;
        parse(str);
        if (str.size()) {
            words.push_back(str);
            counter++;
        }
    }

    return counter;
}

void print(std::vector<std::string> &v) {
    for (std::size_t i = v.size()-50; i < v.size(); i++) {
        std::cout << v[i] << " ";
    }
    std::cout << '\n';
}

// greetings  and introduction 
char greet() {
    char ans;
    std::cout << "\nHello\n" ;
    std::cout << "Behjat bahmani, Lab1 - Sorting text using Selection sort and Bubble sort\n" ;
    std::cout << "In this program we sort data using Selection sort and Bubble sort\n";
    std::cout << "\ndo you want to continue: (y/n) ";
    std::cin >> ans;

    return ans;
}

int main() {
    std::ifstream input { "new.txt" };

    if (!input) {
        std::cerr << "Error! Can't open the file.\n";
        return 1;
    }
    
    std::vector<std::string> sorted;
    std::vector<std::string> words;
    std::string str;
    
    // greet and ask user to type y/n 
    while (true) {
        char ans = greet();
        if (ans == 'n') {
            return 0;
        }

        while (input >> str) {
            for (int i = 0, len = str.size(); i < len; i++) { 
                if (ispunct(str[i])) { 
                    str.erase(i--, 1); 
                    len = str.size();
                } 
            } 
            words.push_back(str);
        }

        std::vector<std::string> original = words;

        std::cout << "\nstarting Bubble Sort...\n";
        std::chrono::duration<double> elapsed_seconds;
        auto start = std::chrono::system_clock::now();
        bubbleSort(words);
        auto end = std::chrono::system_clock::now();
        elapsed_seconds = end - start;
        std::cout << "Sorting unsorted vector took: " << elapsed_seconds.count() << " seconds" << '\n';
        start = std::chrono::system_clock::now();
        bubbleSort(words);
        end = std::chrono::system_clock::now();
        elapsed_seconds = end - start;
        std::cout << "Sorting sorted vector took: " << elapsed_seconds.count() << " seconds" << "\n";


        words = original;
        std::cout << "\nStarting Selection Sort...\n";
        start = std::chrono::system_clock::now();
        selectionSort(words);
        end = std::chrono::system_clock::now();
        elapsed_seconds = end - start;
        std::cout << "Sorting unsorted vector took: " << elapsed_seconds.count() << " seconds" << '\n';
        start = std::chrono::system_clock::now();
        selectionSort(words);
        end = std::chrono::system_clock::now();
        elapsed_seconds = end - start;
        std::cout << "Sorting sorted vector took: " << elapsed_seconds.count() << " seconds" << '\n';

        std::cout << "\nprinting last 50 words in sorted vector: " << '\n';
        print(words);
    }
}
