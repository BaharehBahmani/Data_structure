// Header Gaurds here to prevent duplicate declarations


#ifndef SORT_H
#define SORT_H

#include <string> // std::string
#include <vector> // std::vector


void bubbleSort(std::vector<std::string>& words);
void selectionSort(std::vector<std::string>& words);

#endif