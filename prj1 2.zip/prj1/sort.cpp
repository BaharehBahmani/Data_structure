#include <string>    // std::string
#include <vector>    // std::vector
#include <cstddef>   // std::size_t


void swap(std::string& x, std::string& y) {
    std::string temp = x;
    x = y;
    y = temp;
}

void bubbleSort(std::vector<std::string>& words) {
    std::string temp;
	bool unsorted = true;
	while(unsorted) {
		unsorted = false;
		for (std::size_t i = 0; i < (words.size()-1); i++) {
			if (words[i] > words[i+1]) {
				temp = words[i];
				words[i] = words[ i+1 ];
				words[i+1] = temp;
				unsorted = true;
			}
		}
	}
}

int minPosition(std::vector<std::string>& words, int from, std::size_t to) {
    int minPos = from;
    for (std::size_t i = from + 1; i <= to; i++) {
        if (words[i] < words[minPos])
            minPos = i;
    }
    return minPos;
}

void selectionSort(std::vector<std::string>& words) {
    std::size_t next;
    for (next = 0; next < words.size()-1; next++) {
        int minPos = minPosition(words, next, words.size()-1);
        swap(words[next], words[minPos]);
    }
}