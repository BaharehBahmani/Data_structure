#ifndef SEARCh_H
#define SEARCh_H

#include <string>
#include <vector>


int linearSearch(std::vector<std::string>& words, std::string value);
int binarySearch(std::vector<std::string>& words, int from, int to, std::string value);

#endif