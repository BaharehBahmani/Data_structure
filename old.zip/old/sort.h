#ifndef SORT_H
#define SORT_H

#include <string>
#include <vector>


void bubbleSort(std::vector<std::string>& words);
void insertionSort(std::vector<std::string>& words);
void mergeSort(std::vector<std::string>& words, int from, int to);
void quickSort(std::vector<std::string>& words, int from, int to);
void selectionSort(std::vector<std::string>& words);

#endif