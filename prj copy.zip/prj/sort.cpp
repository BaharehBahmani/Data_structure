#include <string>
#include <vector>
#include <iostream>
#include "sort.h"


void swap(std::string& x, std::string& y) {
    std::string temp = x;
    x = y;
    y = temp;
}

void bubbleSort(std::vector<std::string>& words) {
    std::string temp;
	bool unsorted = true;
	while(unsorted) {
		unsorted = false;
		for (int i = 0; i < (words.size()-1); i++) {
			if (words[i] > words[i+1]) {
				temp = words[i];
				words[i] = words[ i+1 ];
				words[i+1] = temp;
				unsorted = true;
			}
		}
	}
}

void insertionSort(std::vector<std::string>& words) {
    for (int i = 1; i < words.size(); i++) {
        std::string next = words[i];
        int j = i;
        while (j > 0 && words[j - 1] > next) {
            words[j] = words[j - 1];
            j--;
        }
        words[j] = next;
    }
}

void merge(std::vector<std::string>& words, int from, int mid, int to)
{
    int n = to - from + 1; // Size of the range to be merged
    // Merge both halves into a temporary array b
    // We allocate the array dynamically since its size is only
    // known at run time--see Section 7.4
    std::string* b = new std::string[n];

    int i1 = from;
    // Next element to consider in the first half
    int i2 = mid + 1;
    // Next element to consider in the second half
    int j = 0; // Next open position in b

    // As long as neither i1 nor i2 is past the end, move the smaller
    // element into b

    while (i1 <= mid && i2 <= to) {
        if (words[i1] < words[i2]) {
            b[j] = words[i1];
            i1++;
        }
        else {
            b[j] = words[i2];
            i2++;
        }
        j++;
    }

    // Note that only one of the two while loops below is executed

    // Copy any remaining entries of the first half
    while (i1 <= mid) {
        b[j] = words[i1];
        i1++;
        j++;
    }
    // Copy any remaining entries of the second half
    while (i2 <= to) {
        b[j] = words[i2];
        i2++;
        j++;
    }

    // Copy back from the temporary array
    for (j = 0; j < n; j++) {
        words[from+j] = b[j];
    }

    // The temporary array is no longer needed.
    delete[] b;
}

void mergeSort(std::vector<std::string>& words, int from, int to) {
    if (from == to)
        return;
    int mid = (from + to) / 2;
    mergeSort(words, from, mid);
    mergeSort(words, mid + 1, to);
    merge(words, from, mid, to);
}

int partition(std::vector<std::string>& words, int from, int to) {
    std::string pivot = words[from];
    int i = from - 1;
    int j = to + 1;
    while (i < j) {
        i++;
        while (words[i] < pivot) {
            i++;
        }
        j--;
        while (words[j] > pivot) {
            j--;
        }
        if (i < j) {
            swap(words[i], words[j]);
        }
    }
    return j;
}

void quickSort(std::vector<std::string>& words, int from, int to) {
    if (from >= to)
        return;
    int p = partition(words, from, to);
    quickSort(words, from, p);
    quickSort(words, p+1, to);
}

int minPosition(std::vector<std::string>& words, int from, int to) {
    int minPos = from;
    for (int i = from + 1; i <= to; i++) {
        if (words[i] < words[minPos])
            minPos = i;
    }
    return minPos;
}

void selectionSort(std::vector<std::string>& words) {
    int next;
    for (next = 0; next < words.size()-1; next++) {
        int minPos = minPosition(words, next, words.size()-1);
        swap(words[next], words[minPos]);
    }
}