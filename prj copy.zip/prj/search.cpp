#include <string>
#include <vector>
#include "search.h"

int linearSearch(std::vector<std::string>& words, std::string value) {
    for (int i = 0; i < words.size(); i++) {
        if (words[i] == value) {
            return i;
        }
    }
    return -1;
}

int binarySearch(std::vector<std::string>& words, int from, int to, std::string& value) {
    if (from > to) {
        return -1;
    }

    int mid = (from + to) / 2;
    if (words[mid] == value) {
        return mid;
    }
    else if (words[mid] < value) {
        return binarySearch(words, mid+1, to, value);
    }
    else {
        return binarySearch(words, from, mid-1, value);
    }
}