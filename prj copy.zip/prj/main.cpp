#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <ctime>
#include <chrono>
#include <iomanip>
#include "sort.h"
#include "search.h"

int greet();
void menu(int& fileOne, int& fileTwo, int& algOne, int& algTwo, std::string* fileRes, std::string* algsRes);
void parse(std::string& str);
void print(std::vector<std::string>& words);
int read(std::fstream& file, std::vector<std::string>& words);

int main()
{
    std::vector<std::string> words5k;
    std::vector<std::string> words10k;
    std::vector<std::string> words20k;

    std::string fileRes[3] {"5000 words", "10000 words", "20000 words"};
    std::string algsRes[5] {"Selection Sort", "Bubble Sort", "Insertion Sort", "Quick Sort", "Merge Sort"};

    int ans;
    ans = greet();
    if (ans) return 0;

    std::fstream inf5k { "input5k.txt" };
    std::fstream inf10k { "input10k.txt" };
    std::fstream inf20k { "input20k.txt" };

    if (!inf5k || !inf10k || !inf20k) {
        std::cerr << "Error! Couldn't open one of the files.\n";
        return 1;
    }

    int counter5k;
    int counter10k;
    int counter20k;

    // Reading files;
    counter5k = read(inf5k, words5k);
    counter10k = read(inf10k, words10k);
    counter20k = read(inf20k, words20k);

    std::vector<std::string> unsorted5k {words5k};
    std::vector<std::string> unsorted10k {words10k};
    std::vector<std::string> unsorted20k {words20k};
    std::vector<std::string> sorted5k {words5k};
    std::vector<std::string> sorted10k {words10k};
    std::vector<std::string> sorted20k {words20k};
    quickSort(sorted5k, 0, words5k.size()-1);
    quickSort(sorted10k, 0, words10k.size()-1);
    quickSort(sorted20k, 0, words20k.size()-1);


    int fileOne;
    int fileTwo;
    int algOne;
    int algTwo;
    menu(fileOne, fileTwo, algOne, algTwo, fileRes, algsRes);

    std::cout << "Sorting Unsorted 5000 Words File:\n\n";
    // https://stackoverflow.com/questions/997946/how-to-get-current-time-and-date-in-c
    double total {};
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << "Selection Sort:";
    for (int i = 0; i < 5; i++) {
        unsorted5k = words5k;
        auto start = std::chrono::system_clock::now();
        selectionSort(unsorted5k);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Bubble Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        unsorted5k = words5k;
        auto start = std::chrono::system_clock::now();
        bubbleSort(unsorted5k);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Insertion Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        unsorted5k = words5k;
        auto start = std::chrono::system_clock::now();
        insertionSort(unsorted5k);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Quick Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        unsorted5k = words5k;
        auto start = std::chrono::system_clock::now();
        quickSort(unsorted5k, 0, unsorted5k.size()-1);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Merge Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        unsorted5k = words5k;
        auto start = std::chrono::system_clock::now();
        mergeSort(unsorted5k, 0, unsorted5k.size()-1);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;

    /* ------------------------------------------------------------------------------*/

    std::cout << "\nSorting Sorted 5000 Words File:\n\n";
    total = 0;
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << "Selection Sort:";
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        bubbleSort(sorted5k);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Bubble Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        bubbleSort(sorted5k);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Insertion Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        insertionSort(sorted5k);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Quick Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        quickSort(sorted5k, 0, unsorted5k.size()-1);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << "Merge Sort:";
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        mergeSort(sorted5k, 0, unsorted5k.size()-1);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;

    std::cout << "index: " << linearSearch(words5k, "green") << std::endl;
}


void parse(std::string& str) {
    for (int i = str.size()-1; i >= 0; --i) {
        if (!std::isalpha(str[i])) {
            str.erase(str.begin() + i);
        }
        str[i] = std::tolower(str[i]);
    }
    if (!str.compare("and") || !str.compare("the") || !str.compare("a")) {
        str = "";
    }
}

int read(std::fstream& file, std::vector<std::string>& words) {
    int counter {};
    while (file) {
        std::string str;
        file >> str;
        parse(str);
        if (str.size()) {
            words.push_back(str);
            counter++;
        }
    }

    return counter;
}

void print(std::vector<std::string>& words) {
    for (int i { 0 }; i < 20; ++i) {
        std::cout << words[i] << ", ";
    }
    std::cout << words[21] << std::endl;
}

int greet() {
    auto time = std::chrono::system_clock::now();
    time_t now = std::chrono::system_clock::to_time_t(time);
    std::cout << "Hello, Welcome!\t" << std::ctime(&now) << std::endl;
    std::cout << "";

    char ans;
    while (true) {
        std::cout << "Do you want to try the program? (y/n) ";
        std::cin >> ans;
        if (ans == 'y') return 0;
        else if (ans == 'n') return 1;
        else std::cout << "Please respond with 'y' and 'n'\n";
    }
}

void menu(int& fileOne, int& fileTwo, int& algOne, int& algTwo, std::string* fileRes, std::string* algsRes) {
    while (true) {

        std::cout << "Please choose 2 files (Enter a number)" << std::endl;
        std::cout << "1.5000 words file\n2.10000 words file\n3.20000 words file\n\nFirst: ";
        std::cin >> fileOne;
        std::cout << "Second: ";
        std::cin >> fileTwo;

        std::cout << "\nPlease choose 2 algorithms (Enter a number)" << std::endl;
        std::cout << "1. Selection Sort\n2. Bubble Sort\n3. Insertion Sort\n4. Quick Sort\n5. Merge Sort:\n\nFirst: ";
        std::cin >> algOne;
        std::cout << "Second: ";
        std::cin >> algTwo;

        if ((fileOne < 1 && fileOne > 3) || (fileTwo < 1 && fileTwo > 3) || (algOne < 1 && algOne > 5) || (algTwo < 1 && algTwo > 5))
            std::cout << "There was a problem!\nPlease Enter again.\n";
        else if ((fileOne == fileTwo) || (algOne == algTwo))
            std::cout << "There was a problem!\nPlease Enter again.\n";
        else {
            std::cout << "You chose " << fileRes[fileOne-1] << " & " << fileRes[fileTwo-1] << " files.\n";
            std::cout << "You chose " << algsRes[algOne-1] << " & " << algsRes[algTwo-1] << " algorithms.\n\n";
            return;
        }
    }
}