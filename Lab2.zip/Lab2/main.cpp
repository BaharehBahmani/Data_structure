#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <ctime>
#include <chrono>
#include <iomanip>
#include "sort.h"
#include "search.h"
//forward declaration
int greet();
void printLast(std::vector<std::string>& words5k, std::vector<std::string>& words10k, std::vector<std::string>& words20k);
void printFirst(std::vector<std::string>& words5k, std::vector<std::string>& words10k, std::vector<std::string>& words20k);
void menu(int& fileOne, int& fileTwo, int& algOne, int& algTwo, std::string* fileRes, std::string* algsRes);
void parse(std::string& str);
void print(std::vector<std::string>& words);
int read(std::fstream& file, std::vector<std::string>& words);
void quickSortWrapper(std::vector<std::string> &words);
void mergeSortWrapper(std::vector<std::string> &words);
typedef void(*sortFunctions)(std::vector<std::string>&);
void printTableSorts(sortFunctions* sortFunc, std::vector<std::string>* arr, int fOne, int fTwo, int algOne, int algTwo);

  //create two arrays
std::string fileRes[3] {"5000 words", "10000 words", "20000 words"};
std::string algsRes[5] {"Selection Sort", "Bubble Sort", "Insertion Sort", "Quick Sort", "Merge Sort"};

int main()
{
     //create three vectors
    //http://www.cplusplus.com/reference/vector/vector/assign/
    std::vector<std::string> words5k;
    std::vector<std::string> words10k;
    std::vector<std::string> words20k;

 // create a variable ans and call greet
    int ans;
    ans = greet();
    if (ans) return 0;
 //read function
    std::fstream inf5k { "input5k.txt" };
    std::fstream inf10k { "input10k.txt" };
    std::fstream inf20k { "input20k.txt" };


    typedef void(*sortFunctions)(std::vector<std::string>&);
    sortFunctions sortFuncs[] = {selectionSort, bubbleSort, insertionSort, quickSortWrapper, mergeSortWrapper};

 //Error Handling
    if (!inf5k || !inf10k || !inf20k) {
        std::cerr << "Error! Couldn't open one of the files.\n";
        return 1;
    }
  //three variables for counter
    int counter5k;
    int counter10k;
    int counter20k;

    // three counter files;
    std::cout << "\nReading Files...\n";
    counter5k = read(inf5k, words5k);
    counter10k = read(inf10k, words10k);
    counter20k = read(inf20k, words20k);
    //print howmany word each files has
    std::cout << "After reading and cleaning files,\n\n" << std::setw(10) << counter5k << " words saved for first file\n";
    std::cout << std::setw(10) << counter10k << " words saved for second file\n";
    std::cout << std::setw(10) << counter20k << " words saved for third file\n\n";

    //creat a vector to save unsorted files
    std::vector<std::string> unsortedWordsArray[] = {words5k, words10k, words20k};
    //create three vector for unsorting files 
    std::vector<std::string> unsorted5k {words5k};
    std::vector<std::string> unsorted10k {words10k};
    std::vector<std::string> unsorted20k {words20k};
    //create three vector for sorting files 
    std::vector<std::string> sorted5k {words5k};
    std::vector<std::string> sorted10k {words10k};
    std::vector<std::string> sorted20k {words20k};
    //sorting files by quicksort algorithm
    quickSortWrapper(sorted5k);
    quickSortWrapper(sorted10k);
    quickSortWrapper(sorted20k);

    //create two int for saving files name
    int fileOne;
    int fileTwo;
    //create two int for saving algorithm name
    int algOne;
    int algTwo;
    //menu include the names of variable and two arrays
    menu(fileOne, fileTwo, algOne, algTwo, fileRes, algsRes);
    printTableSorts(sortFuncs, unsortedWordsArray, fileOne, fileTwo, algOne, algTwo);
    //search a world in linear and binaery search
    std::string word;
    int num;
    std::cout << "\n\nPlease enter a word: ";
    std::cin >> word;
    std::cout << "Search in which file? (enter a number) \n\n" << std::setw(5) << "1. 5000 words file\n";
    std::cout << std::setw(5) << "2. 10000 words file\n";
    std::cout << std::setw(5) << "3. 20000 words file\n\n";
    std::cout << "Enter a number: ";
    std::cin >> num;
    std::cout << std::endl;
    // start to calculate the times 
    int indexLinear;
    double total = 0;
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << "Linear Search";
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        indexLinear = linearSearch(unsortedWordsArray[num-1], word);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    // start to calculate the times 
    int indexBinary;
    std::vector<std::string> sorted = unsortedWordsArray[num-1];
    std::cout << std::setw(20) << "Binary Search";
    auto start = std::chrono::system_clock::now();
    quickSortWrapper(sorted);
    auto end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end - start;
    double sortTime = elapsed_seconds.count();
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        indexBinary = binarySearch(sorted, 0, sorted.size()-1, word);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout << std::setprecision(5) << std::setw(13) << total+sortTime / 5 << std::endl;
    std::cout << "\n\n***Linear Search was performed on unsorted words and Binary Search was"
                  " performed on sorted words (sorted using quick sort).\n\n";

    std::cout << "the first occurence of the word you entered (" << word << \
                 ") on unsorted " << fileRes[num-1] << " file using linear search was found in index: " << indexLinear << '\n';
    
    std::cout << "the first occurence of the word you entered (" << word << \
                 ") on sorted " << fileRes[num-1] << " file using binary search was found in index: " << indexBinary << '\n';

    std::cout << "For Binary Search it took " << sortTime << " to sort.\n\n\n";
  /*-------------------------------------------------------------------------------------------------------------------*/    
//write a while loop to print last or first 50 words of text
    while (true) {
        std::string answer;
        std::cout << "Do you want to see first or last 50 words of your sorted words? (last, first) ";
        std::cin >> answer;
        if (answer == "last") {
            printLast(sorted5k, sorted10k, sorted20k);
            break;
        }
        else if (answer == "first") {
            printFirst(sorted5k, sorted10k, sorted20k);
            break;
        }
        else std::cout << "Please Enter last or first.\n\n";
    }

    std::cout << "\n\n";
    main();
}

//parse and clean the text file, orgnize bt alphabet and change them to lower
void parse(std::string& str) {
    for (int i = str.size()-1; i >= 0; --i) {
        if (!std::isalpha(str[i])) {
            str.erase(str.begin() + i);
        }
        str[i] = std::tolower(str[i]);
    }
    //clean the file from these three word
    if (!str.compare("and") || !str.compare("the") || !str.compare("a")) {
        str = "";
    }
}
//read files
int read(std::fstream& file, std::vector<std::string>& words) {
    int counter {};
    while (file) {
        std::string str;
        file >> str;
        parse(str);
        if (str.size()) {
            words.push_back(str);
            counter++;
        }
    }

    return counter;
}
/*------------------------------------------------------------------------------------------------*/
//https://www.geeksforgeeks.org/print-last-10-lines-of-a-given-file/
//https://en.cppreference.com/w/cpp/types/size_t
//https://stackoverflow.com/questions/38289521/c-string-size-t
//creat a function to print first 50 words in each text file
void printFirst(std::vector<std::string>& words5k, std::vector<std::string>& words10k, std::vector<std::string>& words20k) {
    std::cout << "\n\n" << std::setw(20) << "5000 words" << std::setw(30) << "10000 words" << std::setw(30) << "20000 words\n";
    for (std::size_t i { 0 }; i < 50; ++i) {
        std::cout << std::setw(20) << words5k[i] << std::setw(30) << words10k[i] << std::setw(30) << words20k[i] << std::endl;
    }
}
//creat a function to print last 50 words in each text file
void printLast(std::vector<std::string>& words5k, std::vector<std::string>& words10k, std::vector<std::string>& words20k) {
    std::cout << "\n\n" << std::setw(20) << "5000 words" << std::setw(30) << "10000 words" << std::setw(30) << "20000 words\n";
    std::size_t size5k = words5k.size() - 1;
    std::size_t size10k = words10k.size() - 1;
    std::size_t size20k = words20k.size() - 1;
    for (std::size_t i { 1 }; i < 51; ++i) {
        std::cout << std::setw(20) << words5k[size5k-i] << std::setw(30) << words10k[size10k-i] \
                  << std::setw(30) << words20k[size20k-i] << std::endl;
    }
}

/*--------------------------------------------------------------------------------------------------*/
//greet function
int greet() {
    auto time = std::chrono::system_clock::now();
    time_t now = std::chrono::system_clock::to_time_t(time);
    std::cout << "Hello, Welcome!\t" << std::ctime(&now) << std::endl;
    std::cout << "This program helps you to chose two text-files and two sorting algorithm from five sorting lgorithm  and calculate, compare their time's sorting in sort or unsort files. And also searching a word and print 50 last/first word of text files.\n";

    char ans;
    while (true) {
        std::cout << "Do you want to try the program? (y/n) ";
        std::cin >> ans;
        if (ans == 'y') return 0;
        else if (ans == 'n') return 1;
        else std::cout << "Please respond with 'y' and 'n'\n";
    }
}
//https://www.youtube.com/watch?v=SWZfFNyUsxc&t=312s
//https://www.w3schools.com/cpp/cpp_function_reference.asp
//https://www.geeksforgeeks.org/passing-by-pointer-vs-passing-by-reference-in-c/
void menu(int& fileOne, int& fileTwo, int& algOne, int& algTwo, std::string* fileRes, std::string* algsRes) {
    while (true) {

        std::cout << "Please choose 2 files (Enter a number)\n" << std::endl;
        std::cout << std::setw(10) << "1.5000 words file\n2.10000 words file\n3.20000 words file\n\nFirst: ";
        std::cin >> fileOne;
        std::cout << "Second: ";
        std::cin >> fileTwo;

        std::cout << "\nPlease choose 2 algorithms (Enter a number)\n" << std::endl;
        std::cout << "1. Selection Sort\n2. Bubble Sort\n3. Insertion Sort\n4. Quick Sort\n5. Merge Sort:\n\nFirst: ";
        std::cin >> algOne;
        std::cout << "Second: ";
        std::cin >> algTwo;
        //holding error
        if ((fileOne < 1 && fileOne > 3) || (fileTwo < 1 && fileTwo > 3) || (algOne < 1 && algOne > 5) || (algTwo < 1 && algTwo > 5))
            std::cout << "There was a problem!\nPlease Enter again.\n";
        else if ((fileOne == fileTwo) || (algOne == algTwo))
            std::cout << "There was a problem!\nPlease Enter again.\n";
        else {
            std::cout << std::setw(5) << "\nYou chose " << fileRes[fileOne-1] << " & " << fileRes[fileTwo-1] << " files.\n";
            std::cout << std::setw(5) << "You chose " << algsRes[algOne-1] << " & " << algsRes[algTwo-1] << " algorithms.\n\n";
            return;
        }
    }
}

void quickSortWrapper(std::vector<std::string>& words) {
    std::size_t size { words.size()-1 };
    quickSort(words, 0, size);
}

void mergeSortWrapper(std::vector<std::string>& words) {
    std::size_t size { words.size()-1 };
    mergeSort(words, 0, size);
}

typedef void(*sortFunctions)(std::vector<std::string>&);
void printTableSorts(sortFunctions* sortFunc, std::vector<std::string>* arr, int fOne, int fTwo, int algOne, int algTwo) {
    std::cout << "- Sorting unsorted " << fileRes[fOne-1] << " file:\n\n";
    std::vector<std::string> unsorted = arr[fOne-1];
    // https://stackoverflow.com/questions/997946/how-to-get-current-time-and-date-in-c
    double total {};
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << algsRes[algOne-1];
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algOne-1])(unsorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
        unsorted = arr[fOne-1];
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << algsRes[algTwo-1];
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algTwo-1])(unsorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
        unsorted = arr[fOne-1];
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << "\n- Sorting unsorted " << fileRes[fTwo-1] << " file:\n\n";
    unsorted = arr[fTwo-1];
    total = 0;
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << algsRes[algOne-1];
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algOne-1])(unsorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
        unsorted = arr[fTwo-1];
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << algsRes[algTwo-1];
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algTwo-1])(unsorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
        unsorted = arr[fTwo-1];
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;

    /*-------------------------------SORTED-------------------------------------------*/

    std::cout << "\n- Sorting sorted " << fileRes[fOne-1] << " file:\n\n";
    std::vector<std::string> sorted = arr[fOne-1];
    quickSortWrapper(sorted);
    // https://stackoverflow.com/questions/997946/how-to-get-current-time-and-date-in-c
    total = 0;
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << algsRes[algOne-1];
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algOne-1])(sorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << algsRes[algTwo-1];
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algTwo-1])(sorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << "\n- Sorting sorted " << fileRes[fTwo-1] << " file:\n\n";
    sorted = arr[fTwo-1];
    quickSortWrapper(sorted);
    total = 0;
    std::cout << std::setw(33) << "First" << std::setw(13) << "Second" << std::setw(13) << "Third" << std::setw(13)\
                               << std::setw(13) << "Fourth" << std::setw(13) << "Fifth" << std::setw(13) << "Average\n";
    std::cout << std::setw(20) << algsRes[algOne-1];
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algOne-1])(sorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout << std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout << std::setprecision(5) << std::setw(13) << total / 5 << std::endl;
    std::cout << std::setw(20) << algsRes[algTwo-1];
    total = 0;
    for (int i = 0; i < 5; i++) {
        auto start = std::chrono::system_clock::now();
        (sortFunc[algTwo-1])(sorted);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
        std::cout <<  std::setprecision(5) << std::setw(13) << elapsed_seconds.count();
        total += elapsed_seconds.count();
    }
    std::cout <<  std::setprecision(5) << std::setw(13) << total / 5 << std::endl;

}